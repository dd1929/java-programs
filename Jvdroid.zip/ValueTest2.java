public class ValueTest {
	public static void main(String[] args) {
		int x = 6;
		x = myAgeNow(x);
		System.out.println("I am now " + x + " years old.");
	}
	public static int myAgeNow (int num){
		return num = num *2;
	}
}