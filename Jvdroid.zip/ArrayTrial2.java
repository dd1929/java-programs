import java.util.Scanner;

public  class ArrayTrial2 {
	public static void main(String []args){
		int [] a = {51, 62, 91, 50};
		int sum=0;
		for(int x:a){
			sum += x;
		};
		System.out.println(sum);
	}
}