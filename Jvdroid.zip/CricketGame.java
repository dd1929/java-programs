import java.util.Scanner;
import java.util.Random;

public class CricketGame {
	public static void main(String[] args) {
		
	}
}