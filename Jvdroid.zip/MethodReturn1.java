public class MethodTest{
	static int product(int x, int y){
		return x * y;
	}
	public static void main(String [] args){
		int a = product(8, 4);
		System.out.println(a);
	}
}