import java.util.Scanner;

public class MyCalculator {
	public static void main(String[] args) {
		System.out.println("Enter first number:");
		Scanner a = new Scanner(System.in);
		int x, y;
		x = a.nextInt();
		System.out.println("Enter second number:");
		Scanner b = new Scanner(System.in);
		y = b.nextInt();
		int sum = x + y;
		int diff = x - y;
		int product = x * y;
		double div = x / y;
		System.out.println("Addition: "+ sum);
		System.out.println("Subtraction: " + diff);
		System.out.println("Multiplication: " + product);
		System.out.println("Division: " + div);
	}
}