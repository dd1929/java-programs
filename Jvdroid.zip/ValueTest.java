public class ValueTest {
	public static void main(String[] args) {
		int x = 5;
		x = addOneTo(x);
		System.out.println(x);
	}
	public static int addOneTo(int num) {
		return num = num + 1;
	}
}