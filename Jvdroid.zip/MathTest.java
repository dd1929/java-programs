public class MathTest{
	public static void main(String[] args) {
		System.out.println(Math.abs(-107373));
		System.out.println(Math.pow(3, 5));
		System.out.println(Math.ceil(-4.653));
		System.out.println(Math.floor(-4.653));
	}
}