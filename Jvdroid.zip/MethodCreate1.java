public class Main {
	static void yoBro(String name){
		System.out.println(name+"Yo Bro!"+name);
	}
	public static void main(String[] args) {
		for (int x=0;x<5;x++){
			yoBro("Gadha");
	}
}
}