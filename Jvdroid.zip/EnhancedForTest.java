public class EnhancedForTest {
	public static void main (String[] args){
		System.out.println("Nobita's friends:");
		String [] names = {"Suneo", "Gian", "Shizuka", "Doraemon"};
		for (String n : names){
			System.out.println("Hello ! My name is " + n + ". I am Nobita's friend!");
		}
	}
}