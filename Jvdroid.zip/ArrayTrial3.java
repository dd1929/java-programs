public class ArrayTrial3{
	public static void main(String [] args){
		int[ ][ ] twodarray = { {4, 51, 9000009}, {61, 78, 89} };
		int x = twodarray [0][2];
		System.out.println(x);
	}
}