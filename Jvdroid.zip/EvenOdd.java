import java.util.Scanner;

public class EvenOdd {
	public static void main(String[] args) {
		System.out.println("Enter a number: ");
		Scanner a = new Scanner(System.in);
		int b = a.nextInt();
		if (b%2 == 0){
			System.out.println("Even");
		}
		else {
			System.out.println("Odd");
		}
	}
}