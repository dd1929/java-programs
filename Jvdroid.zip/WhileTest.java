public class WhileTest {
	public static void main (String[] args){
		int x = 1;
		while (x <= 100){
			System.out.println(x);
			x ++;
		}
	}
}